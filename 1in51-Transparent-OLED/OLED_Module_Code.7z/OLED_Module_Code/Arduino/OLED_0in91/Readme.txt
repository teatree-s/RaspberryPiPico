Arduino
	CS	10
	DC	7
	RST	8
IIC:
	DIN	SDA
	CLK	SCL