Arduino
IIC:
	DIN	SDA
	CLK	SCL