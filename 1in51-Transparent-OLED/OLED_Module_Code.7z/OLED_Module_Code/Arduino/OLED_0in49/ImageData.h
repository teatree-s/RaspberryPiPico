#ifndef _IMAGEDATA_H_
#define _IMAGEDATA_H_

extern const unsigned char gImage_0in49[];	//rotate 90, Color reversal


#endif