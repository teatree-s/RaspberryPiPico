Arduino
	CS	10
	DC	7
	RST	8
SPI:	
	DIN	11	
	CLK	13
IIC:
	DIN	SDA
	CLK	SCL