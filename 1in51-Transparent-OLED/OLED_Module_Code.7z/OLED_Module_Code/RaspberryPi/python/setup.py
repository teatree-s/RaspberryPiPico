import sys
from setuptools import setup
setup(
    name='waveshare-OLED',
    description='Waveshare OLED Display',
    author='Waveshare',
    package_dir={'': 'lib'},
    packages=['waveshare_OLED'],
)

