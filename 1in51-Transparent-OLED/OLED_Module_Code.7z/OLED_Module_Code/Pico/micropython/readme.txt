Pico

SPI:	
	DIN	11	
	CLK	10

IIC：         
	DIN	 8
	CLK	 9

	RST 	12
	CS   	13
	DC   	14